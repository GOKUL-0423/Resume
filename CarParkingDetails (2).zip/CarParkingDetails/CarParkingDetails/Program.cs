﻿using System;
using System.Collections.Generic;


namespace CarParkingDetails
{
    class Program
    {
        static void Main()
        {
            List<CarDetails> carDetails = new List<CarDetails>();
            int mainChoice ;string mainOption = ""; int chargeHours=0;
            do
            {
                Console.WriteLine("1.Parking 2.ShowDetails 3.Exit");
                mainChoice = int.Parse(Console.ReadLine());
                switch (mainChoice)
                {
                    case 1:
                        Parking();
                        Console.Write("If You want to continue (yes/no): ");
                        mainOption = Console.ReadLine().ToUpper();
                        break;
                    case 2:
                        ShowCarDetails();
                        
                        Console.Write("If You want to continue (yes/no): ");
                        mainOption = Console.ReadLine().ToUpper();
                        break;
                    case 3:
                        Exit();
                        Console.Write("If You want to continue (yes/no): ");
                        mainOption = Console.ReadLine().ToUpper();
                        break;
                    default:
                        Console.Write("Thank You! Come Again!");
                        break;
                }
            } while (mainOption == "YES");
            void Parking()
            {
                    
                int count = 0;
                bool flag = true;
                    
                if (count < 20)
                    
                {
                   
                    flag = false;
                        
                    Console.Write("Enter Your Car Name: ");
                        
                    string carName = Console.ReadLine();
                        
                    CarDetails parkingDetails = new CarDetails(carName, DateTime.Now);
                        
                    carDetails.Add(parkingDetails);
                        
                    Console.WriteLine("Your Car is ready to park !" );
                    }
                    if(flag==true)
                {
                    Console.WriteLine("Slots Are Full!");
                }
                
            }
           
            void Exit()
            {
                Console.WriteLine("Enter your CarID: ");
                int exitChoice =int.Parse( Console.ReadLine());
                foreach (CarDetails detail in carDetails)
                {
                    
                    if (exitChoice==detail.CarId)
                    {
                        detail.OutTime = DateTime.Now;
                        Console.WriteLine("You Are ready To Exit!");
                    }
                    
                }
                Console.WriteLine("How Many Hour you Parked: ");
                
                chargeHours = int.Parse(Console.ReadLine());
                Console.WriteLine("Your Bill is :" + chargeHours * 20);

            }
            void ShowCarDetails()
            {
                foreach (CarDetails detail in carDetails)
                {
                    Console.WriteLine("CarName: " + detail.CarName);
                    Console.WriteLine("CarID: " + detail.CarId);
                    Console.WriteLine("Car InTime: " + detail.Intime);
                   
                    Console.WriteLine("Car OutTime: " + detail.OutTime);
                    

                }
                
            }
            Console.ReadLine();
            
        }
    }
}
