﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarParkingDetails
{
    class CarDetails
    {
        private static int s_carId = 1;
        public string CarName { get; set; }
        public int CarId { get; set; }
        public DateTime Intime { get; set; }
         
        public DateTime OutTime { get; set; }  



        public CarDetails(string carName,  DateTime intime)
        {
            CarName = carName;
            CarId = s_carId;
            Intime = intime;
            
            
            s_carId++;
        }
    }
}
